var mybutton = document.getElementById("myBtn");
window.onscroll = function() {scrollFunction()};  
  function scrollFunction() {
    if (document.body.scrollTop > 20 || document.documentElement.scrollTop > 20) {
      mybutton.style.display = "block";
    } else {
      mybutton.style.display = "none";
    }
  }
  function topFunction() {
    // document.body.scrollTop = 0;
    $("html, body").animate( 
      { scrollTop: "0" }, 3000); 
}

$('#myCarousel').carousel({
  interval: 10000
})

$('.carousel .carousel-item').each(function(){
    var PerSlide = 3;
    var next = $(this).next();
    if (!next.length) {
    next = $(this).siblings(':first');
    }
    next.children(':first-child').clone().appendTo($(this));
    
    for (var i=0;i<PerSlide;i++) {
        next=next.next();
        if (!next.length) {
        	next = $(this).siblings(':first');
      	}        
        next.children(':first-child').clone().appendTo($(this));
      }
});

$(document).ready(function(){
  $(".nav-link").click(function(event){
    var target = $(event.target);   
      var href = $(this).attr('href');
      $("html, body").animate( 
        { scrollTop: $(href).offset().top }, 3000); 
  });

   $(".dropdown-item").click(function(event){
    var target = $(event.target);   
      var href = $(this).attr('href');
      // $(href).hide();
      // $(href).show(2000);
      $("html, body").animate( 
        { scrollTop: $(href).offset().top }, 3000); 
   });
});