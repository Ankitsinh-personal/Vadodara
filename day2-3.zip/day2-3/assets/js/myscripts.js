function validate(){
    var x = document.forms["myform"]["name"].value;
    if (x==""){
        alert("Name can not empty");
        return false;
    }
    else{
        document.getElementById("data").innerHTML = "Name: " +x;
    }

    var x = document.forms["myform"]["email"].value;
    if (x==""){
        alert("Email can not empty");
        return false;
    }
    else
    {
        if(/^[a-zA-Z0-9._-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,4}$/.test(x)){
            document.getElementById("data1").innerHTML = "Email: " +x;            
        }
        else
        {   alert("email  not true");        }

    }
    
    var x = document.forms["myform"]["service"].value;
    if (x==""){
        alert("Please select services");
        return false;
    }
    else{
        document.getElementById("data2").innerHTML = "Service: " +x;
    }

    var x = document.forms["myform"]["phone"].value;
    if(x=="")
    {
        alert("phone number can not empty");
        return false;
    }
    else
    {
        if(x.length == 10)
        {
            document.getElementById("data3").innerHTML="Phone: " +x;
        }
        else
        {       
            alert("please enter valid number");
            return false;
        }
    }

    var x = document.forms["myform"]["message"].value;
    if (x==""){
        alert("Please enter message");
        return false;
    }
    else{
        document.getElementById("data4").innerHTML = "Message: " +x;
    }
}